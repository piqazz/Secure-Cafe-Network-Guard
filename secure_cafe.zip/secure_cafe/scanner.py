import time
import socket
import sqlite3
import uuid
import os
import subprocess
from concurrent.futures import ThreadPoolExecutor

DB_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(DB_DIR, "network_guard.db")
last_subnet_prefix = None

def get_db_connection():
    conn = sqlite3.connect(DB_PATH, timeout=30.0)
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    return conn

def get_system_settings():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT scan_interval, log_retention FROM settings WHERE id = 1")
        row = cursor.fetchone()
        conn.close()
        if row:
            interval, retention = row
            return {'scan_interval': int(interval), 'log_retention': int(retention)}
    except Exception as e:
        print(f"[!] Error fetching system settings: {e}")
    return {'scan_interval': 15, 'log_retention': 7}

def resolve_hostname_by_ip(ip, local_ip):
    if ip == local_ip:
        return "Main Laptop (Host Monitor)"
    if ip.endswith(".1"):
        return "Local Gateway Router"
    try:
        hostname, _, _ = socket.gethostbyaddr(ip)
        if hostname and hostname != ip:
            for suffix in [".home", ".lan", ".local", ".localdomain"]:
                if hostname.endswith(suffix):
                    hostname = hostname[:-len(suffix)]
            return hostname
    except Exception:
        pass
    try:
        fqdn = socket.getfqdn(ip)
        if fqdn and fqdn != ip:
            return fqdn
    except Exception:
        pass

    parts = ip.split('.')
    last_part = parts.pop()
    return f"Connected-Device-{last_part}"

def guess_device_type_by_mac(mac, hostname=""):
    mac = mac.lower().replace('-', ':')
    mac_parts = mac.split(":")
    part1, part2, part3, part4, part5, part6 = mac_parts
    prefix = f"{part1}{part2}{part3}"

    host_lower = hostname.lower() if hostname else ""

    if "iphone" in host_lower:
        return "Smartphone (Apple iPhone)"
    if "ipad" in host_lower:
        return "Tablet (Apple iPad)"
    if "android" in host_lower:
        return "Smartphone (Android)"
    if "galaxy" in host_lower:
        return "Smartphone (Samsung)"
    if "surface" in host_lower:
        return "Tablet/PC (Microsoft Surface)"
    if "desktop" in host_lower or "laptop" in host_lower or "pc" in host_lower or "win" in host_lower:
        return "Laptop/PC (Windows/Mac)"
        
    oui_database = {
        "fcfa48": "Apple Device", "fcfc48": "Apple Device", "3ca616": "Apple Device",
        "0000f0": "Samsung Galaxy", "10777d": "Samsung Galaxy",
        "000347": "Intel Host NIC", "000c41": "Intel Host NIC",
        "0007da": "MediaTek NIC", "bc542f": "MediaTek NIC"
    }

    if prefix in oui_database:
        brand = oui_database[prefix]
        if "apple" in brand.lower():
            return "Smartphone/Laptop (Apple)"
        if "samsung" in brand.lower():
            return "Smartphone/Tablet (Samsung)"
        return "Laptop/PC"
    return "Smartphone/Tablet"

def get_my_gateway_info():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip, local_port = s.getsockname()
        s.close()

        part1, part2, part3, part4 = local_ip.split(".")
        subnet_range = f"{part1}.{part2}.{part3}.0/24"
        gateway_ip = f"{part1}.{part2}.{part3}.1"
        subnet_prefix = f"{part1}.{part2}.{part3}."
        
        return subnet_range, gateway_ip, local_ip, subnet_prefix
    except Exception as e:
        print(f"[!] Unable to autodetect network properties, using default: {e}")
        return "192.168.1.0/24", "192.168.1.1", "192.168.1.100", "192.168.1."

def get_host_mac_address():
    try:
        mac_num = uuid.getnode()
        mac_hex = '%012X' % mac_num
        h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12 = list(mac_hex)
        mac_str = f"{h1}{h2}:{h3}{h4}:{h5}{h6}:{h7}{h8}:{h9}{h10}:{h11}{h12}"
        return mac_str.lower()
    except Exception:
        return "00:aa:bb:cc:dd:ee"

def ping_target(ip):
    try:
        subprocess.Popen(f"ping -n 1 -w 100 {ip}", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass

def trigger_ping_sweep(subnet_prefix):
    print(f"[*] Dispatching rapid ping sweep to refresh host tables across {subnet_prefix}* ...")
    ips = [f"{subnet_prefix}{i}" for i in range(1, 255)]
    with ThreadPoolExecutor(max_workers=50) as executor:
        executor.map(ping_target, ips)
    time.sleep(1.2)

def fetch_local_devices(subnet_prefix, local_ip):
    devices = []
    try:
        arp_data = subprocess.check_output("arp -a", shell=True).decode('utf-8', errors='ignore')
        for line in arp_data.splitlines():
            columns = line.strip().split()
            if len(columns) >= 3:
                ip = ""
                mac = ""
                conn_type = "dynamic"

                for col in columns:
                    col_clean = col.strip().lower()
                    if "." in col_clean and not ip:
                        ip = col_clean
                    elif ("-" in col_clean or ":" in col_clean) and len(col_clean) >= 12 and not mac:
                        mac = col_clean.replace('-', ':').lower()
                    elif col_clean in ["dynamic", "static"]:
                        conn_type = col_clean

                if ip and mac:
                    if ip.startswith(subnet_prefix) and ip != local_ip and "dynamic" in conn_type:
                        devices.append({'ip': ip, 'mac': mac})
    except Exception as e:
        print(f"[!] Error reading system ARP cache: {e}")
    return devices

def execute_engine_cycle():
    global last_subnet_prefix

    settings = get_system_settings()
    scan_interval = settings['scan_interval']
    log_retention = settings['log_retention']

    subnet_range, gateway_ip, local_ip, subnet_prefix = get_my_gateway_info()
    local_mac = get_host_mac_address()

    # --- AUTO-PURGE OLD NETWORK INVENTORY ON SWITCH ---
    if last_subnet_prefix is not None and last_subnet_prefix != subnet_prefix:
        print(f"\n🔄 [WIFI CHANGE DETECTED] Swapped from {last_subnet_prefix}* to {subnet_prefix}*")
        try:
            conn = get_db_connection()
            with conn:
                conn.execute("DELETE FROM devices WHERE mac_address != ?", (local_mac,))
                conn.execute("UPDATE threat_logs SET status = 'resolved' WHERE status = 'active'")
            conn.close()
            print("[+] Previous Wi-Fi client entries successfully pruned.")
        except Exception as e:
            print(f"[!] Auto-refresh database clean failure: {e}")
            
    last_subnet_prefix = subnet_prefix

    print(f"\nConnected Gateway Router IP: {gateway_ip}")
    print(f"[*] Local Host Machine: IP: {local_ip} | MAC: {local_mac}")

    trigger_ping_sweep(subnet_prefix)
    devices = fetch_local_devices(subnet_prefix, local_ip)

    filtered_devices = [d for d in devices if d['ip'] != gateway_ip]
    print(f"[*] Mapped {len(filtered_devices)} active client terminal(s).")

    active_macs = [local_mac] + [dev['mac'] for dev in filtered_devices]

    conn = get_db_connection()
    with conn:
        # Purge devices that disconnected or are no longer on active scan
        placeholders = ','.join('?' * len(active_macs))
        conn.execute(f"DELETE FROM devices WHERE mac_address NOT IN ({placeholders})", active_macs)

        # Register host laptop
        conn.execute('''
            INSERT INTO devices (mac_address, ip_address, device_name, device_type, status, notes)
            VALUES (?, ?, 'Main Laptop (Host Monitor)', 'Laptop/PC', 'authorized', 'Active administrator console')
            ON CONFLICT(mac_address) DO UPDATE SET ip_address = excluded.ip_address, last_seen = CURRENT_TIMESTAMP
        ''', (local_mac, local_ip))
        
        # Register discovered clients
        for dev in filtered_devices:
            if dev['ip'] == local_ip or dev['mac'] == local_mac:
                continue
                
            name = resolve_hostname_by_ip(dev['ip'], local_ip)
            dev_type = guess_device_type_by_mac(dev['mac'], name)
            
            conn.execute('''
                INSERT INTO devices (mac_address, ip_address, device_name, device_type, status)
                VALUES (?, ?, ?, ?, 'unknown')
                ON CONFLICT(mac_address) DO UPDATE SET 
                    ip_address = excluded.ip_address,
                    device_name = CASE 
                        WHEN devices.device_name LIKE 'Connected-Device-%' OR devices.device_name IS NULL OR devices.device_name = '' 
                        THEN excluded.device_name 
                        ELSE devices.device_name 
                    END,
                    device_type = CASE 
                        WHEN devices.device_type IS NULL OR devices.device_type = '' OR devices.device_type = 'Smartphone/Tablet'
                        THEN excluded.device_type
                        ELSE devices.device_type
                    END,
                    last_seen = CURRENT_TIMESTAMP
            ''', (dev['mac'], dev['ip'], name, dev_type))
            
    # Attack 1 Check: Severe Wi-Fi Slowness (DNS Latency > 800ms)
    try:
        dns_start = time.time()
        socket.gethostbyname("google.com")
        dns_latency = int((time.time() - dns_start) * 1000)

        if dns_latency > 800:
            with conn:
                cursor = conn.cursor()
                cursor.execute("SELECT COUNT(*) FROM threat_logs WHERE anomaly_detected = 'Severe Wi-Fi Slowness' AND status = 'active'")
                row = cursor.fetchone()
                has_active = row if row else 0

                if has_active == 0:
                    conn.execute('''
                        INSERT INTO threat_logs (anomaly_detected, protocol, details, mitigation_step, status, timestamp)
                        VALUES (
                            'Severe Wi-Fi Slowness',
                            'DNS',
                            ?,
                            'Check active devices for high load, ask users if large files are downloading, and restart router if needed.',
                            'active',
                            datetime('now', 'localtime')
                        )
                    ''', (f"High network response latency of {dns_latency}ms detected on local DNS lookups.",))
    except Exception:
        pass

    # Attack 2 Check: Device Connection Conflict (ARP)
    gateway_mac = "00:11:22:33:44:55"
    for dev in devices:
        if dev['ip'] == gateway_ip:
            gateway_mac = dev['mac']
            break

    with conn:
        for dev in devices:
            if dev['ip'] == gateway_ip and dev['mac'] != gateway_mac:
                print(f"🔥 Device Connection Conflict Detected! Intruder MAC: {dev['mac']}!")
                
                cursor = conn.cursor()
                cursor.execute("SELECT COUNT(*) FROM threat_logs WHERE details LIKE ? AND status = 'active'", (f"%{dev['mac']}%",))
                row_count = cursor.fetchone()
                
                has_active = row_count if row_count else 0
                
                if has_active == 0:
                    conn.execute('''
                        INSERT INTO threat_logs (anomaly_detected, protocol, details, mitigation_step, status, timestamp)
                        VALUES (
                            'Device Connection Conflict',
                            'ARP',
                            ?,
                            'Unplug your main Wi-Fi router for 10 seconds and plug it back in to safely reset all connections.',
                            'active',
                            datetime('now', 'localtime')
                        )
                    ''', (f"An unrecognized device (MAC: {dev['mac']}) is conflicting with your main router's IP settings.",))

        # Dynamic cleanup using log retention settings
        conn.execute("DELETE FROM threat_logs WHERE timestamp < datetime('now', '-' || ? || ' days')", (str(log_retention),))

    conn.close()
    return scan_interval

if __name__ == '__main__':
    print("==========================================================")
    print("      SECURE CAFE: BASIC NETWORK MONITOR ENGINE          ")
    print("==========================================================")
    while True:
        try:
            scan_interval = execute_engine_cycle()
            print(f"[*] Cycle complete. Listening in 1-second ticks for network alterations...")

            break_sleep = False
            for tick in range(scan_interval):
                time.sleep(1)
                
                _, _, _, current_prefix = get_my_gateway_info()
                if last_subnet_prefix is not None and last_subnet_prefix != current_prefix:
                    print("\n🔄 [WIFI CHANGE DETECTED MID-SLEEP] Instantly waking scanner to update segment details!")
                    break_sleep = True
                    break
                
                current_settings = get_system_settings()
                if current_settings['scan_interval'] != scan_interval:
                    print(f"\n⚙️ [SETTINGS UPDATED MID-SLEEP] Dynamic interval shifting from {scan_interval}s to {current_settings['scan_interval']}s!")
                    break_sleep = True
                    break
            
            if break_sleep:
                continue
            
        except KeyboardInterrupt:
            print("\n[!] Scanner stopped.")
            break
        except Exception as e:
            print(f"[!] Engine Loop Crash Prevented: {e}")
            time.sleep(10)
