from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import sqlite3
import os
from datetime import datetime
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
app.secret_key = 'super_secret_cybersecurity_cafe_key'

DB_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(DB_DIR, "network_guard.db")

def get_db_connection():
    conn = sqlite3.connect(DB_PATH, timeout=30.0)
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.row_factory = sqlite3.Row
    return conn

@app.after_request
def add_security_headers(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response

# Live Refresh Polling API
@app.route('/api/threat-status')
def threat_status():
    conn = get_db_connection()
    threat_row = conn.execute("SELECT COUNT(*) as count FROM threat_logs WHERE status = 'active'").fetchone()
    device_row = conn.execute("SELECT COUNT(*) as count FROM devices").fetchone()
    conn.close()

    state_signature = f"t:{threat_row['count']}|d:{device_row['count']}"
    return jsonify({
        "state_signature": state_signature,
        "active_threats": threat_row["count"]
    })

# Secret Phone Web Trigger: Attack 2 (Device Connection Conflict / ARP)
@app.route('/simulate-attack')
def web_simulate():
    conn = get_db_connection()
    local_time_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with conn:
        conn.execute("DELETE FROM threat_logs WHERE details LIKE '%99:AA:BB:CC:DD:EE%' AND status = 'active'")
        conn.execute('''
            INSERT INTO threat_logs (anomaly_detected, protocol, details, mitigation_step, status, timestamp)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            'Device Connection Conflict',
            'ARP',
            "An unrecognized device is conflicting with your main router's IP settings. This can block other customers from connecting.",
            'Unplug your main Wi-Fi router for 10 seconds and plug it back in to safely reset all connections.',
            'active',
            local_time_str
        ))
    conn.close()
    return """
    <div style='text-align: center; font-family: sans-serif; margin-top: 50px; padding: 20px;'>
        <h2 style='color: #ef4444;'>🔥 ARP ATTACK TRIGGERED SUCCESSFULLY!</h2>
        <p style='font-size: 1.1rem; color: #1e293b;'>Look at your laptop's Web Dashboard—it has automatically turned red with an active threat alert!</p>
        <p style='color: #64748b;'>Return to the laptop dashboard to click "VIEW SIMPLE FIX".</p>
    </div>
    """

# Secret Phone Web Trigger: Attack 1 (Severe Wi-Fi Slowness / DNS)
@app.route('/simulate-dns-attack')
def web_simulate_dns():
    conn = get_db_connection()
    local_time_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with conn:
        conn.execute("DELETE FROM threat_logs WHERE anomaly_detected = 'Severe Wi-Fi Slowness' AND status = 'active'")
        conn.execute('''
            INSERT INTO threat_logs (anomaly_detected, protocol, details, mitigation_step, status, timestamp)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            'Severe Wi-Fi Slowness',
            'DNS',
            'High network response latency of 1250ms detected on local DNS lookups. Bandwidth congestion detected on local segment.',
            'Check active devices for high load, ask users if large files are downloading, and restart router if needed.',
            'active',
            local_time_str
        ))
    conn.close()
    return """
    <div style='text-align: center; font-family: sans-serif; margin-top: 50px; padding: 20px;'>
        <h2 style='color: #ef4444;'>⚡ DNS SLOWNESS ATTACK TRIGGERED!</h2>
        <p style='font-size: 1.1rem; color: #1e293b;'>Look at your laptop's Web Dashboard—it has automatically turned bright red with the Wi-Fi Slowness alert!</p>
        <p style='color: #64748b;'>Return to the laptop dashboard to view the simple fix checklist.</p>
    </div>
    """

# Authentication Routes
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()

        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        conn.close()

        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = user['role']
            flash(f"Welcome back, {username}!", 'success')
            return redirect(url_for('dashboard'))
        flash('Login Failed: Invalid credentials.', 'danger')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        role = request.form.get('role', 'staff')

        if len(password) < 6:
            flash('Error: Password must be at least 6 characters long.', 'danger')
            return redirect(url_for('register'))

        hashed_password = generate_password_hash(password)
        conn = get_db_connection()
        try:
            with conn:
                conn.execute('INSERT INTO users (username, password, role) VALUES (?, ?, ?)', (username, hashed_password, role))
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Username already exists.', 'danger')
        finally:
            conn.close()
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully.', 'info')
    return redirect(url_for('login'))

# Core Dashboard View
@app.route('/')
@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    devices = conn.execute('SELECT * FROM devices ORDER BY last_seen DESC').fetchall()
    active_threats = conn.execute("SELECT * FROM threat_logs WHERE status = 'active' ORDER BY timestamp DESC").fetchall()
    all_threats = conn.execute("SELECT * FROM threat_logs ORDER BY timestamp DESC").fetchall()
    conn.close()

    total_devices = len(devices)
    authorized_count = sum(1 for d in devices if d['status'] == 'authorized')
    unknown_count = total_devices - authorized_count
    active_threats_count = len(active_threats)
    network_health = 100 if active_threats_count == 0 else max(100 - (active_threats_count * 25), 10)

    # Select the most recent active threat item directly
    active_threat_item = active_threats[0] if len(active_threats) > 0 else None

    return render_template('dashboard.html', 
                           devices=devices[:5], 
                           threats=all_threats[:5], 
                           active_threat_item=active_threat_item,
                           total_devices=total_devices,
                           authorized_count=authorized_count,
                           unknown_count=unknown_count,
                           network_health=network_health,
                           active_threats=active_threats_count)

# Resolve Specific Threat Item Route (Single Incident Mitigation)
@app.route('/threats/resolve/<int:threat_id>', methods=['POST'])
def resolve_threat(threat_id):
    if 'user_id' not in session:
        flash('Unauthorized command.', 'danger')
        return redirect(url_for('dashboard'))

    conn = get_db_connection()
    with conn:
        conn.execute("UPDATE threat_logs SET status = 'resolved' WHERE id = ?", (threat_id,))
    conn.close()
    flash('Incident mitigated successfully! Checking for remaining network threats...', 'success')
    return redirect(url_for('dashboard'))

# Resolve All Threats (Backup Batch Action)
@app.route('/threats/resolve-all', methods=['POST'])
def resolve_all_threats():
    if 'user_id' not in session:
        flash('Unauthorized command.', 'danger')
        return redirect(url_for('dashboard'))

    conn = get_db_connection()
    with conn:
        conn.execute("UPDATE threat_logs SET status = 'resolved' WHERE status = 'active'")
    conn.close()
    flash('Defensive routing tables restored. All active threats marked as resolved.', 'success')
    return redirect(url_for('dashboard'))

# Inventory Management View
@app.route('/inventory', methods=['GET', 'POST'])
def inventory():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    if request.method == 'POST' and session.get('role') == 'admin':
        mac = request.form.get('mac_address', '').strip()
        status = request.form.get('status', 'unknown')
        notes = request.form.get('notes', '').strip()
        device_name = request.form.get('device_name', '').strip()
        device_type = request.form.get('device_type', '').strip()

        with conn:
            conn.execute('''
                UPDATE devices 
                SET status = ?, notes = ?, device_name = ?, device_type = ? 
                WHERE mac_address = ?
            ''', (status, notes, device_name, device_type, mac))
        flash('Device parameters updated.', 'success')

    devices = conn.execute('SELECT * FROM devices ORDER BY last_seen DESC').fetchall()
    conn.close()
    return render_template('inventory.html', devices=devices)

@app.route('/inventory/delete/<string:mac>', methods=['POST'])
def delete_device(mac):
    if session.get('role') != 'admin':
        flash('Unauthorized.', 'danger')
        return redirect(url_for('inventory'))
    conn = get_db_connection()
    with conn:
        conn.execute('DELETE FROM devices WHERE mac_address = ?', (mac,))
    conn.close()
    return redirect(url_for('inventory'))

@app.route('/threats')
def threats():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    conn = get_db_connection()
    threat_logs = conn.execute('SELECT * FROM threat_logs ORDER BY timestamp DESC').fetchall()
    conn.close()
    return render_template('threats.html', threats=threat_logs)

@app.route('/settings', methods=['GET', 'POST'])
def settings():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    if request.method == 'POST':
        action = request.form.get('action')

        if action == 'update_settings':
            if session.get('role') != 'admin':
                flash('Access Restricted to Admins.', 'danger')
                return redirect(url_for('settings'))

            scan_interval = int(request.form.get('scan_interval', 15))
            log_retention = int(request.form.get('log_retention', 7))

            with conn:
                conn.execute('UPDATE settings SET scan_interval = ?, log_retention = ? WHERE id = 1', (scan_interval, log_retention))
            flash('Settings updated successfully.', 'success')

        elif action == 'update_profile':
            username = request.form.get('username', '').strip()
            password = request.form.get('password', '').strip()
            user_id = session['user_id']

            if not username:
                flash('Username cannot be empty.', 'danger')
            else:
                try:
                    with conn:
                        if password:
                            hashed_pw = generate_password_hash(password)
                            conn.execute('UPDATE users SET username = ?, password = ? WHERE id = ?', (username, hashed_pw, user_id))
                        else:
                            conn.execute('UPDATE users SET username = ? WHERE id = ?', (username, user_id))

                    session['username'] = username
                    flash('Your operator profile was updated successfully!', 'success')
                except sqlite3.IntegrityError:
                    flash('Username already exists. Choose a different name.', 'danger')

        return redirect(url_for('settings'))

    system_settings = conn.execute('SELECT * FROM settings WHERE id = 1').fetchone()
    current_user = conn.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
    conn.close()
    return render_template('settings.html', settings=system_settings, user=current_user)

@app.route('/users', methods=['GET', 'POST'])
def users():
    if 'user_id' not in session or session.get('role') != 'admin':
        return redirect(url_for('dashboard'))

    conn = get_db_connection()
    if request.method == 'POST':
        action = request.form.get('action')
        target_id = request.form.get('user_id')

        if int(target_id) == session['user_id']:
            flash('You cannot change or delete your own active administrator profile!', 'danger')
        else:
            with conn:
                if action == 'toggle_role':
                    user = conn.execute('SELECT * FROM users WHERE id = ?', (target_id,)).fetchone()
                    new_role = 'staff' if user['role'] == 'admin' else 'admin'
                    conn.execute('UPDATE users SET role = ? WHERE id = ?', (new_role, target_id))
                    flash('User operational authorization level modified.', 'success')
                elif action == 'delete_user':
                    conn.execute('DELETE FROM users WHERE id = ?', (target_id,))
                    flash('Operator deleted successfully.', 'warning')

    all_users = conn.execute('SELECT * FROM users').fetchall()
    conn.close()
    return render_template('users.html', users=all_users)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)