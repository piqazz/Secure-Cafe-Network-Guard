import sqlite3
import os
from werkzeug.security import generate_password_hash

DB_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(DB_DIR, "network_guard.db")

def init_db():
    if os.path.exists(DB_PATH):
        try:
            os.remove(DB_PATH)
            print("[+] Removed old database file to start fresh.")
        except Exception as e:
            print(f"[!] Warning: Could not remove old DB file: {e}")

    conn = sqlite3.connect(DB_PATH, timeout=30.0)
    cursor = conn.cursor()

    cursor.execute("PRAGMA journal_mode=WAL;")

    # 1. Operators Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'staff'
        )
    ''')

    # 2. Devices Inventory Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS devices (
            mac_address TEXT PRIMARY KEY,
            ip_address TEXT,
            device_name TEXT,
            device_type TEXT,
            status TEXT DEFAULT 'unknown',
            notes TEXT,
            last_seen TIMESTAMP DEFAULT (datetime('now', 'localtime'))
        )
    ''')

    # 3. Security Threat Logs Table (Local Time Default)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS threat_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TIMESTAMP DEFAULT (datetime('now', 'localtime')),
            anomaly_detected TEXT,
            protocol TEXT,
            details TEXT,
            mitigation_step TEXT,
            status TEXT DEFAULT 'active'
        )
    ''')

    # 4. System Settings Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS settings (
            id INTEGER PRIMARY KEY,
            scan_interval INTEGER DEFAULT 15,
            log_retention INTEGER DEFAULT 7
        )
    ''')

    cursor.execute("INSERT OR REPLACE INTO settings (id, scan_interval, log_retention) VALUES (1, 15, 7)")

    hashed_admin = generate_password_hash('admin123')
    hashed_staff = generate_password_hash('staff123')
    cursor.execute("INSERT OR REPLACE INTO users (id, username, password, role) VALUES (1, 'admin', ?, 'admin')", (hashed_admin,))
    cursor.execute("INSERT OR REPLACE INTO users (id, username, password, role) VALUES (2, 'staff', ?, 'staff')", (hashed_staff,))

    conn.commit()
    conn.close()
    print("[+] Database successfully initialized with Local Time Mode!")

if __name__ == '__main__':
    init_db()
